"use strict";

function Follow(userId, vacationId) {
    this.userId = userId;
    this.vacationId = vacationId;
}

module.exports = {
    Follow:Follow
};